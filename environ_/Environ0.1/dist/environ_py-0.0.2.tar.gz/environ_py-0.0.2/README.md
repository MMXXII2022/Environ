# Environ
Environ is a **python** framework built for you to manage your project in a few clicks, it creates an integrated file environment so your project can be awesome, a shell called EnvironShell which you can use to manage your project ALL IN ONE!


How to access environshell:
` python -m environ shell `


A few EnvironShell commands:
` help `,
` crfile [FILENAME] [CONTENTS] `
"Contents can contain \n to declare newlines"


SHORT CHANGELOG:
* Fixed Dependecy Version Error
* Added License
* Added EnvironShell access point
* Fixed Fetching version